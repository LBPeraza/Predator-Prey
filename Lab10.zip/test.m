myId = 2;

HPS = HowiePositioningSystem;

ids = HPS.getVisibleIds();

if (any(myId == ids))
    myPosition = HPS.getPosition(myId);
end

corners = [-1 -1; -1 -1; -1 -1; -1 -1];
for id = 20:23
    if (any(id == ids))
        i = id - 19;
        position = HPS.getPosition(id);
        corners(i,1) = position.x;
        corners(i,2) = position.y;
    end
end

X = [0 0];
Y = [0 0];
Xn = [0 0];
Yn = [0 0];

if (~(any(corners(1) < 0) || any(corners(2) < 0)))
    X = corners(2,:) - corners(1,:);
    d = 1/norm(X);
    Xn = X * d;
end
if (~(any(corners(4) < 0) || any(corners(1) < 0)))
    Y = corners(4,:) - corners(1,:);
    d = 1/norm(Y);
    Yn = Y * d;
end

xnt = atan2(Xn(2), Xn(1));

trans = [X(1) X(2) -corners(1,1); Y(1) Y(2) -corners(1,2); 0 0 1];

thetaTarget = 0.0;
target = [0.5; 0.5];

kp = 10;
l = 100;

while true
    ids = HPS.getVisibleIds();
    if (any(myId == ids))
        myPosition = HPS.getPosition(myId);
        world = [myPosition.x; myPosition.y; 1];
        frame = trans * world;
        frame(3) = radtodeg(myPosition.th - xnt);
        posError = target - frame(1:2);
        thetaTarget = radtodeg(atan2(posError(2), posError(1)));
        thetaError = thetaTarget - frame(3);
        disp('   ');
        disp(frame(3));
        disp(thetaTarget);
        l = thetaError * kp;
        disp(l);
        set_motor_speed(l, -l);
        pause(0.05);
    else
        stop_motors();
    end
end
