function [] = stop_motors ( )

set_motor_speed(0, 0);

end